$(document).ready(function() {

    $('#logout').click(function(){
        localStorage.type = "";
        localStorage.id = "";
    });
});