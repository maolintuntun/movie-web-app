package com.wqlm.boot.user.dto;
import lombok.Data;

import java.util.List;

@Data
public class PopulateDTO {
    private String eventName;
    private String movieName;
}
