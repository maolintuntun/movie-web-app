package com.wqlm.boot.user.dto;
import lombok.Data;
@Data
public class PullDTO {
    private String eventName;
}
