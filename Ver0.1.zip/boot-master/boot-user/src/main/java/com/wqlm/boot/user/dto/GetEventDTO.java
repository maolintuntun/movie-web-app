package com.wqlm.boot.user.dto;
import lombok.Data;

@Data
public class GetEventDTO {
    private String eventName;
}
