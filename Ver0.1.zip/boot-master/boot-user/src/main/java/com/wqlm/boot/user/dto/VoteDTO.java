package com.wqlm.boot.user.dto;
import lombok.Data;

@Data
public class VoteDTO {
    private String movieName;

    private String watcherName;

    private String eventName;
}
