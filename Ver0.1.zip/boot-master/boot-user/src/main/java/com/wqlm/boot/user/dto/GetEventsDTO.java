package com.wqlm.boot.user.dto;
import lombok.Data;

@Data
public class GetEventsDTO {
    private String type;
    private String account;
}
