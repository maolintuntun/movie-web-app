package com.wqlm.boot.user.dto;
import lombok.Data;
@Data
public class GetMoviesDTO {
    private String eventName;
    private String watcherName;
}
