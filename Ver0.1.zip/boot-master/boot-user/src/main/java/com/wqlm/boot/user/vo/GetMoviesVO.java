package com.wqlm.boot.user.vo;

import lombok.Data;

import java.util.List;

@Data
public class GetMoviesVO {
    List<MoviesVO> movieList;
}
